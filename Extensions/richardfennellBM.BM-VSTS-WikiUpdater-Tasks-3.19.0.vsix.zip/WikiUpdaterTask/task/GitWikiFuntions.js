"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateGitWikiFile = exports.GetTrimmedUrl = exports.GetProtocol = exports.GetWorkingFile = exports.GetWorkingFolder = void 0;
const simple_git_1 = require("simple-git");
const fs = require("fs");
const rimraf = require("rimraf");
const path = require("path");
const process = require("process");
const agentSpecific_1 = require("./agentSpecific");
// A wrapper to make sure that directory delete is handled in sync
function rimrafPromise(localpath) {
    return new Promise((resolve, reject) => {
        rimraf(localpath, () => {
            resolve(0);
        }, (error) => {
            reject(error);
        });
    });
}
function mkDirByPathSync(targetDir, { isRelativeToScript = false } = {}) {
    const sep = path.sep;
    const initDir = path.isAbsolute(targetDir) ? sep : "";
    const baseDir = isRelativeToScript ? __dirname : ".";
    return targetDir.split(sep).reduce((parentDir, childDir) => {
        const curDir = path.resolve(baseDir, parentDir, childDir);
        try {
            fs.mkdirSync(curDir);
        }
        catch (err) {
            if (err.code === "EEXIST") { // curDir already exists!
                return curDir;
            }
            // To avoid `EISDIR` error on Mac and `EACCES`-->`ENOENT` and `EPERM` on Windows.
            if (err.code === "ENOENT") { // Throw the original parentDir error on curDir `ENOENT` failure.
                throw new Error(`EACCES: permission denied, mkdir '${parentDir}'`);
            }
            const caughtErr = ["EACCES", "EPERM", "EISDIR"].indexOf(err.code) > -1;
            if (!caughtErr || caughtErr && curDir === path.resolve(targetDir)) {
                throw err; // Throw if it's just the last created dir.
            }
        }
        return curDir;
    }, initDir);
}
function GetWorkingFolder(localpath, filename, logInfo) {
    var pathParts = path.parse(filename);
    if (pathParts.dir && pathParts.dir !== "/" && pathParts.dir !== "\\") {
        var targetPath = path.join(localpath, path.join(pathParts.dir));
        if (!fs.existsSync(targetPath)) {
            logInfo(`Creating the directory ${targetPath}`);
            mkDirByPathSync(targetPath);
        }
        return targetPath;
    }
    else {
        logInfo(`No sub-directory passed change to ${localpath}`);
        return localpath;
    }
}
exports.GetWorkingFolder = GetWorkingFolder;
function GetWorkingFile(filename, logInfo) {
    var pathParts = path.parse(filename);
    var name = pathParts.base;
    logInfo(`Working file name is ${name}`);
    return name;
}
exports.GetWorkingFile = GetWorkingFile;
function GetProtocol(url, logInfo) {
    var protocol = "https";
    logInfo(`The provided repo URL is ${url}`);
    if (url.indexOf("://") !== -1) {
        protocol = url.substr(0, url.indexOf("//") - 1);
    }
    logInfo(`The protocol is ${protocol}`);
    return protocol;
}
exports.GetProtocol = GetProtocol;
function GetTrimmedUrl(url, logInfo) {
    var fixedUrl = url;
    logInfo(`The provided repo URL is ${fixedUrl}`);
    if (fixedUrl.indexOf("://") !== -1) {
        logInfo(`Removing leading http:// or https:// block`);
        fixedUrl = fixedUrl.substr(fixedUrl.indexOf("://") + 3);
    }
    if (fixedUrl.indexOf("@") !== -1) {
        logInfo(`Removing leading username@ block`);
        fixedUrl = fixedUrl.substr(fixedUrl.indexOf("@") + 1);
    }
    logInfo(`Trimmed the URL to ${fixedUrl}`);
    return fixedUrl;
}
exports.GetTrimmedUrl = GetTrimmedUrl;
function UpdateGitWikiFile(protocol, repo, localpath, user, password, name, email, filename, message, contents, logInfo, logError, replaceFile, appendToFile, tagRepo, tag, injectExtraHeader, sslBackend, branch, maxRetries, trimLeadingSpecialChar, fixLineFeeds, fixSpaces, insertLinefeed, updateOrderFile, prependEntryToOrderFile, orderFilePath, injecttoc, mode) {
    return __awaiter(this, void 0, void 0, function* () {
        var name;
        const git = (0, simple_git_1.default)();
        // show error if content is null
        if (!contents) {
            logError(`The new content is null, so cannot be used to update the wiki`);
            return;
        }
        let remote = "";
        let logremote = ""; // used to make sure we hide the password in logs
        var extraHeaders = []; // Add handling for #613
        if (injectExtraHeader) {
            remote = `${protocol}://${repo}`;
            logremote = remote;
            extraHeaders = [`-c http.extraheader=AUTHORIZATION: bearer ${password}`];
            if (sslBackend) {
                extraHeaders.push(`-c http.sslbackend=${sslBackend}`);
                logInfo(`Injecting http.sslbackend configuration using parameter -c http.sslbackend=${sslBackend}`);
            }
            logInfo(`Injecting the authentication via the clone command using paramter -c http.extraheader='AUTHORIZATION: bearer ***'`);
        }
        else {
            if (password === null) {
                remote = `${protocol}://${repo}`;
                logremote = remote;
            }
            else if (user === null) {
                remote = `${protocol}://${password}@${repo}`;
                logremote = `${protocol}://***@${repo}`;
            }
            else {
                remote = `${protocol}://${user}:${password}@${repo}`;
                logremote = `${protocol}://${user}:***@${repo}`;
            }
        }
        logInfo(`URL used ${logremote}`);
        try {
            if (fs.existsSync(localpath)) {
                yield rimrafPromise(localpath);
            }
            logInfo(`Cleaned ${localpath}`);
            yield git.clone(remote, localpath, extraHeaders);
            logInfo(`Cloned ${repo} to ${localpath}`);
            yield git.cwd(localpath);
            yield git.addConfig("user.name", name);
            yield git.addConfig("user.email", email);
            logInfo(`Set GIT values in ${localpath}`);
            // issue 969 - remove spaces
            if (fixSpaces) {
                name = GetWorkingFile(filename, logInfo);
                if (name.includes(" ")) {
                    logInfo(`The target filename contains spaces which are not valid in WIKIs filename '${name}'`);
                    // we only update the filename portion, not the path. Need to use regex else only first instance changed
                    filename = filename.replace(name, name.replace(/\s/g, "-"));
                    logInfo(`Update filename '${filename}'`);
                }
            }
            // move to the working folder
            var workingPath = GetWorkingFolder(localpath, filename, logInfo);
            process.chdir(workingPath);
            if (branch) {
                logInfo(`Checking out the requested branch ${branch}`);
                yield git.checkout(branch);
            }
            // do git pull just in case the clone was slow and there have been updates since
            // this is to try to reduce concurrency issues
            yield git.pull();
            logInfo(`Git Pull, prior to local commits, in case of post clone updates to the repo from other users`);
            // we need to change any encoded
            var workingFile = GetWorkingFile(filename, logInfo);
            if (replaceFile) {
                if (fixLineFeeds) {
                    logInfo(`Created the '${workingFile}' in '${workingPath}' - fixing line-endings`);
                    fs.writeFileSync(workingFile, contents.replace(/`n/g, "\r\n"));
                }
                else {
                    logInfo(`Created the '${workingFile}' in '${workingPath}' - without fixing line-endings`);
                    fs.writeFileSync(workingFile, contents);
                }
            }
            else {
                if (appendToFile) {
                    if (insertLinefeed) {
                        // fix for #988 trailing new lines are trimmed from inline content
                        (0, agentSpecific_1.logDebug)(`Injecting linefeed between existing and new content`);
                        fs.appendFileSync(workingFile, "\r\n");
                    }
                    // fix for #826 where special characters get added between the files being appended
                    fs.appendFileSync(workingFile, FixedFormatOfNewContent(contents, trimLeadingSpecialChar));
                    logInfo(`Appended to the ${workingFile} in ${workingPath}`);
                }
                else {
                    var oldContent = "";
                    if (fs.existsSync(workingFile)) {
                        oldContent = fs.readFileSync(workingFile, "utf8");
                    }
                    if (injecttoc) {
                        (0, agentSpecific_1.logDebug)(`Replacing old [[_TOC_]] with a new one at the top of the pre-pended content`);
                        oldContent = oldContent.replace("[[_TOC_]]", ""); // we the single existing TOC ignoring the line feeds following
                        fs.writeFileSync(workingFile, "[[_TOC_]]\r\n\r\n"); // we add a 2nd feed, as blank line is required after the TOC
                        (0, agentSpecific_1.logDebug)(`Appending new content after [[_TOC_]]`);
                        fs.appendFileSync(workingFile, contents.replace(/`n/g, "\r\n"));
                    }
                    else {
                        (0, agentSpecific_1.logDebug)(`Writing new content`);
                        fs.writeFileSync(workingFile, contents.replace(/`n/g, "\r\n"));
                    }
                    if (insertLinefeed) {
                        // fix for #988 trailing new lines are trimmed from inline content
                        (0, agentSpecific_1.logDebug)(`Injecting linefeed between existing and new content`);
                        fs.appendFileSync(workingFile, "\r\n");
                    }
                    (0, agentSpecific_1.logDebug)(`Appending old content`);
                    fs.appendFileSync(workingFile, FixedFormatOfNewContent(oldContent, trimLeadingSpecialChar));
                    logInfo(`Prepending to the ${workingFile} in ${workingPath}`);
                }
            }
            yield git.add(filename);
            logInfo(`Added ${filename} to repo ${localpath}`);
            if (updateOrderFile) {
                var orderFile = `${localpath}/.order`;
                if (orderFilePath && orderFilePath.length > 0) {
                    orderFile = `${localpath}/${orderFilePath}/.order`;
                }
                logInfo(`Using the file - ${orderFile}`);
                // we need the name without the extension and the folder path
                var entry = path.basename(filename.replace(/.md/i, ""));
                if (fs.existsSync(orderFile)) {
                    logInfo(`Attempting to updating the existing .order file`);
                    oldContent = fs.readFileSync(orderFile, "utf8");
                }
                else {
                    logInfo(`Attempting to create a new .order file`);
                    oldContent = "";
                }
                // we edit the order file if the new entry is not already in the file
                if (oldContent.includes(entry)) {
                    logInfo(`The entry '${entry}' already exists in the .order file, skipping update`);
                }
                else {
                    if (prependEntryToOrderFile) {
                        // prepending the entry
                        if (fs.existsSync(orderFile)) {
                            oldContent = fs.readFileSync(orderFile, "utf8");
                            // as we are pre-pending we alway need a line feed
                            fs.writeFileSync(orderFile, `${entry}\r\n`);
                            fs.appendFileSync(orderFile, oldContent);
                            logInfo(`Preppending entry to the .order file`);
                        }
                        else {
                            fs.writeFileSync(orderFile, `${entry}`);
                            logInfo(`Creating .order file as it does not exist`);
                        }
                    }
                    else {
                        // appending the entry
                        if (fs.existsSync(orderFile)) {
                            // check the content to make sure we have the required line feed
                            oldContent = fs.readFileSync(orderFile, "utf8");
                            if (!oldContent.endsWith("\r\n")) {
                                fs.appendFileSync(orderFile, "\r\n");
                            }
                        }
                        fs.appendFileSync(orderFile, entry);
                        logInfo(`Appending entry to the .order file`);
                    }
                    yield git.add(orderFile);
                    logInfo(`Added .order file to repo ${localpath}`);
                }
            }
            (0, agentSpecific_1.logDebug)(`Committing the changes with the message: ${message}`);
            var summary = yield git.commit(message);
            if (summary.commit.length > 0) {
                logInfo(`Committed file "${localpath}" with message "${message}" as SHA ${summary.commit}`);
                if (maxRetries < 1) {
                    maxRetries = 1;
                    logInfo(`Setting max retries to 1 and it must be a positive value`);
                }
                for (let index = 1; index <= maxRetries; index++) {
                    try {
                        logInfo(`Attempt ${index} - Push to ${repo}`);
                        yield git.push();
                        logInfo(`Push completed`);
                        break;
                    }
                    catch (err) {
                        if (index < maxRetries) {
                            logInfo(`Push failed, will retry up to ${maxRetries} times after updating the local repo with the latest changes from the server`);
                            logInfo(err);
                            sleep(1000);
                            switch (mode) {
                                case "Rebase":
                                    logInfo(`Pulling with --rebase=true option to get updates from other users`);
                                    if (!branch) {
                                        logError(`Rebase requested, but no branch passed in as a parameter`);
                                        return;
                                    }
                                    yield git.pull("origin", branch, { "--rebase": "true" });
                                    break;
                                default: // Pull
                                    logInfo(`Pull to get updates from other users`);
                                    yield git.pull();
                                    break;
                            }
                        }
                        else {
                            logInfo(`Reached the retry limit`);
                            logError(err);
                            return;
                        }
                    }
                }
                if (tagRepo) {
                    if (tag.length > 0) {
                        logInfo(`Adding tag ${tag}`);
                        yield git.addTag(tag);
                        yield git.pushTags();
                    }
                    else {
                        (0, agentSpecific_1.logWarning)(`Requested to add tag, but no tag passed`);
                    }
                }
            }
            else {
                logInfo(`No commit was performed as the new file has no changes from the existing version`);
            }
        }
        catch (error) {
            logError(error);
        }
    });
}
exports.UpdateGitWikiFile = UpdateGitWikiFile;
function FixedFormatOfNewContent(contents, trimLeadingSpecialChar) {
    // sort out the newlines
    var fixedContents = contents.replace(/`n/g, "\r\n");
    // fix for #826 where special characters get added between the files being appended
    // 65279 is the Unicode Character 'ZERO WIDTH NO-BREAK SPACE'
    if (trimLeadingSpecialChar && fixedContents.charCodeAt(0) === 65279) {
        fixedContents = fixedContents.substr(1);
    }
    return fixedContents;
}
function sleep(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms);
    });
}
//# sourceMappingURL=GitWikiFuntions.js.map
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateGitWikiFolder = exports.GetTrimmedUrl = exports.GetProtocol = exports.GetFolder = exports.GetFileName = exports.GetWorkingFolder = void 0;
const simple_git_1 = require("simple-git");
const fs = require("fs");
const rimraf = require("rimraf");
const path = require("path");
const process = require("process");
const agentSpecific_1 = require("./agentSpecific");
const glob = require("glob");
// A wrapper to make sure that directory delete is handled in sync
function rimrafPromise(localpath) {
    return new Promise((resolve, reject) => {
        rimraf(localpath, () => {
            resolve(0);
        }, (error) => {
            reject(error);
        });
    });
}
function mkDirByPathSync(targetDir, { isRelativeToScript = false } = {}) {
    const sep = path.sep;
    const initDir = path.isAbsolute(targetDir) ? sep : "";
    const baseDir = isRelativeToScript ? __dirname : ".";
    return targetDir.split(sep).reduce((parentDir, childDir) => {
        const curDir = path.resolve(baseDir, parentDir, childDir);
        try {
            fs.mkdirSync(curDir);
        }
        catch (err) {
            if (err.code === "EEXIST") { // curDir already exists!
                return curDir;
            }
            // To avoid `EISDIR` error on Mac and `EACCES`-->`ENOENT` and `EPERM` on Windows.
            if (err.code === "ENOENT") { // Throw the original parentDir error on curDir `ENOENT` failure.
                throw new Error(`EACCES: permission denied, mkdir '${parentDir}'`);
            }
            const caughtErr = ["EACCES", "EPERM", "EISDIR"].indexOf(err.code) > -1;
            if (!caughtErr || caughtErr && curDir === path.resolve(targetDir)) {
                throw err; // Throw if it's just the last created dir.
            }
        }
        return curDir;
    }, initDir);
}
function GetWorkingFolder(localpath, folder, logInfo) {
    if (folder) {
        var targetPath = path.join(localpath, folder);
        if (!fs.existsSync(targetPath)) {
            logInfo(`Creating the directory ${targetPath}`);
            mkDirByPathSync(targetPath);
        }
        return targetPath;
    }
    else {
        logInfo(`No sub-directory passed change to ${localpath}`);
        return localpath;
    }
}
exports.GetWorkingFolder = GetWorkingFolder;
function GetFileName(filename) {
    var pathParts = path.parse(filename);
    return pathParts.base;
}
exports.GetFileName = GetFileName;
function GetFolder(filename, sourceDir) {
    var pathParts = path.parse(filename);
    return (path.relative(sourceDir, pathParts.dir));
}
exports.GetFolder = GetFolder;
function GetProtocol(url, logInfo) {
    var protocol = "https";
    logInfo(`The provided repo URL is ${url}`);
    if (url.indexOf("://") !== -1) {
        protocol = url.substr(0, url.indexOf("//") - 1);
    }
    logInfo(`The protocol is ${protocol}`);
    return protocol;
}
exports.GetProtocol = GetProtocol;
function GetTrimmedUrl(url, logInfo) {
    var fixedUrl = url;
    logInfo(`The provided repo URL is ${fixedUrl}`);
    if (fixedUrl.indexOf("://") !== -1) {
        logInfo(`Removing leading http:// or https:// block`);
        fixedUrl = fixedUrl.substr(fixedUrl.indexOf("://") + 3);
    }
    if (fixedUrl.indexOf("@") !== -1) {
        logInfo(`Removing leading username@ block`);
        fixedUrl = fixedUrl.substr(fixedUrl.indexOf("@") + 1);
    }
    logInfo(`Trimmed the URL to ${fixedUrl}`);
    return fixedUrl;
}
exports.GetTrimmedUrl = GetTrimmedUrl;
function UpdateGitWikiFolder(protocol, repo, localpath, user, password, name, email, targetFolder, message, sourceFolder, filter, logInfo, logError, replaceFile, appendToFile, tagRepo, tag, injectExtraHeader, sslBackend, branch, maxRetries, mode) {
    return __awaiter(this, void 0, void 0, function* () {
        const git = (0, simple_git_1.default)();
        let remote = "";
        let logremote = ""; // used to make sure we hide the password in logs
        var extraHeaders = []; // Add handling for #613
        if (injectExtraHeader) {
            remote = `${protocol}://${repo}`;
            logremote = remote;
            extraHeaders = [`-c http.extraheader=AUTHORIZATION: bearer ${password}`];
            if (sslBackend) {
                extraHeaders.push(`-c http.sslbackend=${sslBackend}`);
                logInfo(`Injecting http.sslbackend configuration using parameter -c http.sslbackend=${sslBackend}`);
            }
            logInfo(`Injecting the authentication via the clone command using paramter -c http.extraheader='AUTHORIZATION: bearer ***'`);
        }
        else {
            if (password === null) {
                remote = `${protocol}://${repo}`;
                logremote = remote;
            }
            else if (user === null) {
                remote = `${protocol}://${password}@${repo}`;
                logremote = `${protocol}://***@${repo}`;
            }
            else {
                remote = `${protocol}://${user}:${password}@${repo}`;
                logremote = `${protocol}://${user}:***@${repo}`;
            }
        }
        logInfo(`URL used ${logremote}`);
        try {
            if (fs.existsSync(localpath)) {
                yield rimrafPromise(localpath);
            }
            logInfo(`Cleaned ${localpath}`);
            yield git.clone(remote, localpath, extraHeaders);
            logInfo(`Cloned ${repo} to ${localpath}`);
            yield git.cwd(localpath);
            yield git.addConfig("user.name", name);
            yield git.addConfig("user.email", email);
            logInfo(`Set GIT values in ${localpath}`);
            // move to the working folder
            process.chdir(localpath);
            if (branch) {
                logInfo(`Checking out the requested branch ${branch}`);
                yield git.checkout(branch);
            }
            // do git pull just in case the clone was slow and there have been updates since
            // this is to try to reduce concurrency issues
            yield git.pull();
            logInfo(`Git Pull, prior to local commits, in case of post clone updates to the repo from other users`);
            // make sure the slashes are in the correct format
            sourceFolder = sourceFolder.replace(/\\/g, "/");
            // get the list of file
            logInfo(`Checking for files using the filter ${sourceFolder}/${filter}`);
            var files = glob.sync(`${sourceFolder}/${filter}`);
            logInfo(`Found ${files.length} files`);
            for (let index = 0; index < files.length; index++) {
                logInfo(`Processing ${files[index]}`);
                var fileName = GetFileName(files[index]);
                var folder = GetFolder(files[index], sourceFolder);
                if (targetFolder) {
                    folder = path.join(targetFolder, folder);
                }
                var workingPath = GetWorkingFolder(localpath, folder, logInfo);
                var targetFile = `${workingPath}/${fileName}`;
                if (replaceFile) {
                    logInfo(`Copying the ${files[index]} to ${targetFile}`);
                    fs.copyFileSync(files[index], targetFile);
                }
                else {
                    var contents = fs.readFileSync(files[index], "utf8");
                    if (appendToFile) {
                        fs.appendFileSync(targetFile, contents.replace(/`n/g, "\r\n"));
                        logInfo(`Appended to ${targetFile}`);
                    }
                    else {
                        var oldContent = "";
                        if (fs.existsSync(targetFile)) {
                            oldContent = fs.readFileSync(targetFile, "utf8");
                        }
                        fs.writeFileSync(targetFile, contents.replace(/`n/g, "\r\n"));
                        fs.appendFileSync(targetFile, oldContent);
                        logInfo(`Prepending to the ${targetFile}`);
                    }
                }
                yield git.add(targetFile);
                logInfo(`Added ${targetFile} to repo ${localpath}`);
            }
            var summary = yield git.commit(message);
            if (summary.commit.length > 0) {
                logInfo(`Committed "${localpath}" with message "${message}" as SHA ${summary.commit}`);
                if (maxRetries < 1) {
                    maxRetries = 1;
                    logInfo(`Setting max retries to 1 and it must be a positive value`);
                }
                for (let index = 1; index <= maxRetries; index++) {
                    try {
                        logInfo(`Attempt ${index} - Push to ${repo}`);
                        yield git.push();
                        logInfo(`Push completed`);
                        break;
                    }
                    catch (err) {
                        if (index < maxRetries) {
                            logInfo(`Push failed, will retry up to ${maxRetries} times after updating the local repo with the latest changes from the server`);
                            logInfo(err);
                            sleep(1000);
                            switch (mode) {
                                case "Rebase":
                                    logInfo(`Pulling with --rebase=true option to get updates from other users`);
                                    if (!branch) {
                                        logError(`Rebase requested, but no branch passed in as a parameter`);
                                        return;
                                    }
                                    yield git.pull("origin", branch, { "--rebase": "true" });
                                    break;
                                default: // Pull
                                    logInfo(`Pull to get updates from other users`);
                                    yield git.pull();
                                    break;
                            }
                        }
                        else {
                            logInfo(`Reached the retry limit`);
                            logError(err);
                            return;
                        }
                    }
                }
                if (tagRepo) {
                    if (tag.length > 0) {
                        logInfo(`Adding tag ${tag}`);
                        yield git.addTag(tag);
                        yield git.pushTags();
                    }
                    else {
                        (0, agentSpecific_1.logWarning)(`Requested to add tag, but no tag passed`);
                    }
                }
            }
            else {
                logInfo(`No commit was performed as no files have been added, deleted or edited`);
            }
        }
        catch (error) {
            logError(error);
        }
    });
}
exports.UpdateGitWikiFolder = UpdateGitWikiFolder;
function sleep(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms);
    });
}
//# sourceMappingURL=GitWikiFuntions.js.map